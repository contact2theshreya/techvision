
name = raw_input('enter name :')
print 'you have entered : ',name

print name.upper()
print name.lower()
print len(name)

ll = list(name)
print ll
print ll[1] ## i 


word = name.split(' ')
print word 
print word[2]
print word[::-1]# reverse string by word

print name[0:3] # 0th, 1st, 2nd 
print name[4:8] 
print name[:8] # 0 to 7th 

print name[::-1]


###
for w in word:
    print w[::-1],



##replace
d = name.replace('a','xy')
print d
print name

###print trim(name)


