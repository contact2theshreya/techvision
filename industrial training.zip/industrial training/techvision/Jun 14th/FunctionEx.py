'''
Function : is set of command/instructions which is reusable
Module: is collection of classes and functions/methods

Advantage:
->reusability of code
->support to modular approach, large/complex task can be written in small set of code

->There are following types of functions:
'''

# no argument no return 
def wel():
    print 'welcome to fun world '

#no argument with return
def getData():
    a =input('enter data  : ')
    n =raw_input('enter name : ')
    return a,n


#argument with no return
def addNum(a,b):
    c =a+b
    print c
#argument with return
def subNum(a,v):
    d = a-v
    return d


## default argument
def dyFun(a,b=0,c=0,d=0,e=0): # with default value
        m =a+b+c+d+e
        print m


### receive multiple arguments
def dyArgs(*args):
    print args
    s = 0
    for x in args:
        s =s+x
    print s
    
    
# call to function
wel()
wel()

o1,o2 = getData()
print o1,o2


o1,o2 = getData()
print o1,o2


addNum(11,2)
addNum(113,24)


a = subNum(111,222)
print a
addNum(a,20)


dyFun(1)
dyFun(1,22)
dyFun(1,3222,3)
dyFun(1,333,2,2)
dyFun(1,222,3,23,2)

dyArgs(1111,2222,2,12,32,2,2,2,2,3,23,3,3,33,32222)


