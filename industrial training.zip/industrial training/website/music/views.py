from django.shortcuts import render
from django.http import HttpResponse 
from django.shortcuts import render_to_response
#from django.conf import settings
from . import dbaccess
from . import connectionex
from django.core.mail import EmailMessage
#from django.core.mail import send_mail

# Create your views here.
#give the url of each page otherwise it will not be displayed


# Create your views here.
#contain all functions and html files
#we cannot declare here python function---inside the function we can declare the python function
#if you want to declare outside python function then do by  ajax
def index(request):
    #return HttpResponse ("hi")
    return render_to_response("music/index.html")
def userform(request):
   return render_to_response("music/userform.html")
def email(request):
    #return HttpResponse ("hi")
    return render_to_response("music/email.html")
def sendmail(request):
    
    f = request.GET['from']
    t = request.GET['to']
    b = request.GET['body']
    s = request.GET['sub']
    #s = connectionex.saveData(n,e,p)
    #return HttpResponse("Data saved ")
    email = EmailMessage(b, s, [t])#'b','s',to=["...."]
    email.send()
    return HttpResponse("Data saved ")

def login(request):
    #return HttpResponse ("hi")
    return render_to_response("music/login.html")

def yash(request):
    #return HttpResponse ("hi")
    return render_to_response("music/yash.html")
    
def save(request):
    fn=request.GET['fn']
    ln =request.GET['ln']

    o = dbaccess.newUser(fn,ln)
    f  = open(r'output.txt','a')
    f.write(fn+','+ln)
    f.close()

    return HttpResponse("data is saved")

def home(request):
    return HttpResponse (" Name : <input type='text'  />  ")
    
def logincheck(request):
    fn=request.GET['fn']
    ln =request.GET['ln']

    o = dbaccess.validateUser(fn,ln)

    return render_to_response("music/home.html",{'data':o})


    return HttpResponse("show"+o)
def saveTest(request):
    n = request.GET['name']
    e = request.GET['email']
    p = request.GET['pwd']
    s = connectionex.saveData(n,e,p)
    return HttpResponse("save the data  ")    

def showTest(request):
    n = request.GET['name']
    e = request.GET['email']
    p = request.GET['pwd']
    o=connectionex.showTest(n,e,p)
    return render_to_response("music/home.html",{'data':o})
