import pandas

data = pandas.read_csv(r'C:\Users\mihir\Desktop\height.csv')

print(data)

print(data.columns)
print(data.shape)
print(data.head(3))
print(data.tail(2))

##show basic statis
'''
count
mean /avg
std. dev
min
25%
50%
75%
max
'''

print(data.describe())







