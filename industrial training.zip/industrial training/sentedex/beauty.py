'''
#from mystudy 7 webscrapping tutorial and sentdex only functions
from urllib2 import urlopen
from bs4 import BeautifulSoup
#import requests
html=urlopen("https://www.youtube.com/watch?v=pL73kMo8Hn8")
#print html.read()
bs=BeautifulSoup(html.read(),"lxml")
tags=bs.findall("span",{"class":"green"})
print tags
'''
#from dataschool
import requests
r=requests.get('https://www.youtube.com/watch?v=pL73kMo8Hn8')
print r.text[0:500]
