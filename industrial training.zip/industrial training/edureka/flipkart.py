from bs4 import BeautifulSoup as soup 
import requests
from urllib2 import urlopen as ureq
myurl='https://www.flipkart.com/search?q=iphone&marketplace=FLIPKART&otracker=start&as-show=on&as=off'
uclient=ureq(myurl)
pagehtml=uclient.read()
uclient.close()
pagesoup=soup(pagehtml,"html.parser")
containers=pagesoup.findAll("div",{"class":"_3O0U0u"})
print(len(containers))
#print(soup.prettify(containers[0]))
container=containers[0]
print(container.div.img["alt"])
price=container.findAll("div",{"class":"col col-5-12 _2o7WAb"})
arr=[]
for string in price[0].stripped_strings:
    arr.append(repr(string))#if container in place of price[0] then it shows ratings also
   # print(repr(string))
''' 
parse the string   
#ratings=container.findAll("div",{"class":"niH0FQ "})   
'''
#print arr
p1=list(arr)
word=p1[0].split('u\'\\u20b9')
print 'Rs'+ word[1]
