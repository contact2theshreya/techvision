from bs4 import BeautifulSoup as soup 
import requests
import pandas
from urllib2 import urlopen as ureq
myurl='https://www.flipkart.com/search?q=iphone&marketplace=FLIPKART&otracker=start&as-show=on&as=off'
uclient=ureq(myurl)
pagehtml=uclient.read()
uclient.close()
pagesoup=soup(pagehtml,"html.parser")
containers=pagesoup.findAll("div",{"class":"_3O0U0u"})
containers1=pagesoup.findAll("img",{"class":"_3BTv9X"})
print(len(containers))
#print(soup.prettify(containers[0]))
container=containers[0]
container1=containers1[0]
count=0
#filename="C:\Users\mihir\Desktop\nidhi\industrial training\edureka\prod.csv"
f=open(r'C:\Users\mihir\Desktop\nidhi\industrial training\edureka\prod.csv',"w")
headers="product_name,pricing,reating,reviews\n"
f.write(headers)
for container in containers:
            count=count+1
            print(count,"############################################################")
            for container1 in containers1:
                image_url = []
                image = container1.find_all("img")[0]
                if image.get("data-src"):
                 img_url = container1.get("data-src")
                else:
                 img_url = container1.get("data-src")
                 image_url.append(img_url)
                print (image_url)
            print(container.div.img["alt"])
            price=container.findAll("div",{"class":"col col-5-12 _2o7WAb"})
            arr=[]
            for string in price[0].stripped_strings:
                arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                #print(repr(string))
            #parse the string   
            #  

            #print arr
            p1=list(arr)
            word=p1[0].split('u\'\\u20b9')
            print 'Rs'+ word[1].replace('\'',' ')
            prod_rat=container.findAll("span",{"class":"_2_KrJI"})
            rat=[]
            for string in prod_rat[0].stripped_strings:
                rat.append(repr(string))#if container in place of price[0] then it shows ratings also
                #print(repr(string))
            r1=list(rat)
            #print r1
            word_rat=r1[0].split('u\'')
            print word_rat[1].replace('\'',' ')
            #calculating ratings and reviews
            rev=container.findAll("span",{"class":"_38sUEc"})  
            #print rev  
            rev1=list(rev)
            #print rev1[0]
            rev_arr=[]
            for string in rev1[0].stripped_strings:
                rev_arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                #print(repr(string))
            #print rev_arr 
            w2=rev_arr[0].split('u\'')
            w3=rev_arr[2].split('u\'')
            print w2[1].replace('\'',' ')
            print w3[1].replace('\'',' ')
            ftrs=container.findAll("ul",{"class":"vFw0gD"}) 
            #print ftrs 
            ftrs_arr=[]
            for string in ftrs[0].stripped_strings:#doubt in ftrs[0]***********************************************************
                ftrs_arr.append(repr(string))#if container in place of price[0] then it shows ratings also
            
            #print ftrs_arr 
            #print len(ftrs_arr)//6 
            ftrs_list=list(ftrs_arr)
            #print ftrs_list

            for i in range(0,len(ftrs_arr)):
                word=ftrs_list[i].split('u\'')
                print word[1].replace('|\'',' ')
            f.write(container.div.img["alt"]+ word[1].replace('\'',' ')+ word_rat[1].replace('\'',' ')+ w3[1].replace('\'',' '))
f.close()




