from bs4 import BeautifulSoup as soup 
import requests
import pandas
from urllib2 import urlopen as ureq
import mysql.connector
c = mysql.connector.connect(user="root",password="root",host="localhost",database="industrial")
c1= mysql.connector.connect(user="root",password="root",host="localhost",database="industrial")
cr = c.cursor()
cr1 = c1.cursor()
myurl='https://www.flipkart.com/search?q=iphones&marketplace=FLIPKART&otracker=start&as-show=on&as=off&page=2'
uclient=ureq(myurl)
pagehtml=uclient.read()
uclient.close()
pagesoup=soup(pagehtml,"html.parser")
containers=pagesoup.findAll("div",{"class":"_3O0U0u"})
print(len(containers))
#print(soup.prettify(containers[0]))
container=containers[0]
count=0
#filename="C:\Users\mihir\Desktop\nidhi\industrial training\edureka\prod.csv"
'''
f=open(r'C:\Users\mihir\Desktop\nidhi\industrial training\edureka\prod.csv',"w")
headers="product_name,pricing,reating,reviews\n"
f.write(headers)
'''
for container in containers:
            count=count+1
            print(count,"############################################################")
            print(container.div.img["alt"])
            price=container.findAll("div",{"class":"col col-5-12 _2o7WAb"})
            arr=[]
            for string in price[0].stripped_strings:
                arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                #print(repr(string))
            #parse the string   
            #  

            #print arr
            p1=list(arr)
            word5=p1[0].split('u\'\\u20b9')
            print word5
           
            
            price_new=word5[1].replace('\'',' ')
            w8=price_new.split(',')
            prr=w8[0]+w8[1]
            print prr
            prod_rat=container.findAll("span",{"class":"_2_KrJI"})
            rat=[]
            for string in prod_rat[0].stripped_strings:
                    rat.append(repr(string))#if container in place of price[0] then it shows ratings also
                        #print(repr(string))
            r1=list(rat)
            prod_rat=container.findAll("span",{"class":"_2_KrJI"})
            rat=[]
            for string in prod_rat[0].stripped_strings:
                    rat.append(repr(string))#if container in place of price[0] then it shows ratings also
                        #print(repr(string))
            r1=list(rat)
                
            word_rat=r1[0].split('u\'')
                
            w_rat=word_rat[1].split('R')
               
            word_rat=r1[0].split('u\'')
                
            w_rat=word_rat[1].split('R')
            rev=container.findAll("span",{"class":"_38sUEc"})  
            #print rev  
            rev1=list(rev)
            #print rev1[0]
            rev_arr=[]
            for string in rev1[0].stripped_strings:
                rev_arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                #print(repr(string))
            print rev_arr 
            w2=rev_arr[0].split('u\'')
            w2_rat=w2[1].split('R')
            
            #r1=w2_rat[0].split(',')
            #print r1[0]+r1[1]
            w3=rev_arr[2].split('u\'')
            w_rev=w3[1].split('R')
            print 'Ratings'+w2_rat[0]
            print 'Reviews'+ w_rev[0]
            #print w3[1].replace('\'',' ')
            ftrs=container.findAll("ul",{"class":"vFw0gD"}) 
            #print ftrs 
            ftrs_arr=[]
            for string in ftrs[0].stripped_strings:#doubt in ftrs[0]***********************************************************
                ftrs_arr.append(repr(string))#if container in place of price[0] then it shows ratings also
            
            #print ftrs_arr 
            #print len(ftrs_arr)//6 
            ftrs_list=list(ftrs_arr)
            #print ftrs_list
            
            for i in range(0,len(ftrs_arr)):
                word=ftrs_list[i].split('u\'')
                print word[1].replace('\'',' ')
                w_f=word[1].replace('\'',' ')
                ft="insert into crawl2(id,features) values('"+container.div.img["alt"]+"','"+w_f+"')"
                cr1.execute(ft)
                c1.commit()
            st ="insert into crawl(name,price,rating,reviews) values('"+container.div.img["alt"]+"','"+prr+"','"+w2_rat[0]+"','"+w_rev[0]+"')"
            cr.execute(st)
     
        
            c.commit()
            
name="Apple iPhone SE (Gold, 64 GB)"            #f.write(container.div.img["alt"]+ word[1].replace('\'',' ')+ word_rat[1].replace('\'',' ')+ w3[1].replace('\'',' '))
#cr.execute("SELECT MIN(Price) AS SmallestPrice FROM crawl")
#cr.execute("select * from crawl where name='"+name+"'")
cr.execute("select * from crawl where (price) in (select min(price) from crawl)")

res = cr.fetchall()

a=[]
d=[]
print "######################################################"
for r in res:
    a.append(r[0])
    a.append(r[1])

d.append(a)
for i in d:
    for k in i:
        print k
               
        
     




