import MySQLdb

con = MySQLdb.connect('localhost','root','root','emp') 
cr = con.cursor()
f= open(r'C:\Users\mihir\Desktop\employee.txt','r')
f.readline()

lines=f.readlines()
count=0
for r in lines:
    count+=1
    w=r.split(',')
    if count==1:
       continue
    cr.execute("insert into emp(id,name,gender) values("+w[0]+",'"+w[1]+"',"+w[2].replace('\n','')+")")

#save data 
con.commit()
f.close()
#print '1 row inserted'



## read data
cr.execute('select * from emp')

res = cr.fetchall()
for r in res:
    print r

con.close()





