from django.contrib import admin
from django.conf.urls import include, url
from . import views
#contain all functions and html
urlpatterns = [  
    url('saveTest$',views.saveTest,name="saveTest"),
    url('showTest$',views.showTest,name="showTest"),  
    url('home$',views.home,name="home"),
    url('userform$',views.userform,name="userform"),
    url('sendmail$',views.sendmail,name="sendmail"),
    url('email$',views.email,name="email"),
    url('save$',views.save,name="save"),    
    url('yash$',views.yash,name="yash"),
    url('logincheck$',views.logincheck,name='logincheck'),
    url('login$',views.login,name="login"),
    url('',views.index,name="index"), # landing / default page 
    
]
