from django.db import models
class album(models.Model):
    artist=models.CharField(max_length=250)
    album_title=models.CharField(max_length=500)
    genre=models.CharField(max_length=100)
    album_logo=models.CharField(max_length=1000)
# Create your models here.
class song(models.Model):
    album=models.ForeignKey(album,on_delete=models.CASCADE)
    file_type=models.CharField(max_length=10)
    song_title=models.CharField(max_length=250)
class emp(models.Model):#run individually makemigration and migrate before running server each time when you create new
    name=models.CharField(max_length=10)
    file_type=models.CharField(max_length=10)
    song_title=models.CharField(max_length=250)
   