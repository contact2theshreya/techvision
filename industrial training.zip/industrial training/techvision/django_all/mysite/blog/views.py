from django.shortcuts import render
from django.http import HttpResponse 
from django.shortcuts import render_to_response
# Create your views here.


def index(request):
    #return HttpResponse ("hi")
    return render_to_response("blog/index.html")

def yash(request):
    #return HttpResponse ("hi")
    return render_to_response("blog/yash.html")
    
def save(request):
    fn=request.GET['fn']
    ln =request.GET['ln']

    f  = open(r'output.txt','a')
    f.write(fn+','+ln)
    f.close()







    return HttpResponse("data is saved")



def home(request):
    return HttpResponse (" Name : <input type='text'  />  ")
    
