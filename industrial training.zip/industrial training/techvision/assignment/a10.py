days=input('enter no. of days')
y=days/365
m=days%365
w=m/7
days=m%7
print 'days:',days,'year:',y,'week:',w,