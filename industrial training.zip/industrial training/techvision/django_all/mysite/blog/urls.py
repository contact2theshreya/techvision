from django.contrib import admin
from django.conf.urls import include, url
from . import views

urlpatterns = [    
    url('home$',views.home,name="home"),
    url('save$',views.save,name="save"),    
    url('yash$',views.yash,name="yash"),
    url('',views.index,name="index"), # landing / default page 
    
]
