unit = input('enter unit')

if unit <=100:
    print 40*unit + 50
elif unit >100 and unit <=300:
    print 50*unit + 50
else    :
    print 60*unit + 50
