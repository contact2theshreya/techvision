'''
india - 2 - 4658
nepal - 2 - 6590
'''
f= open(r'C:\Users\mihir\Desktop\test.txt','r')

f.readline()

lines=f.readlines()

uq = []
noc=[]
salc=[]

for r in lines:

    word=r.split(',')

    if word[3] not in uq:

        uq.append(word[3])
for i in range(0,len(uq)):
    sum=0
    sal=0
    for r in lines:
          w=r.split(',')
          if uq[i]==w[3]:
               sum+=1
               sal+=int(w[4].replace('\n',''))
           

    noc.append(sum)       
    salc.append(sal)
     
for i in range(0,len(uq)):
    print uq[i],'-',noc[i],'-',salc[i]

        




'''
other way of doing if statically country is  being picked
print lines

mo=0

fo=0

isal=0

osal=0



for r in lines:

    word=r.split(',')

    if word[3]=='india':

        mo=mo+1        

        isal = isal + int(word[4].replace('\n',''))

        

    elif word[3]=='us':

        fo=fo+1

        osal = osal + int(word[4].replace('\n',''))

        

print 'india',mo,isal

print 'us',fo,osal
'''
f.close()


          
       
        
        
        
            
    
    

