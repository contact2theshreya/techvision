'''
class stu:
    def input(self):
        self.name=raw_input('enter name:')
        self.roll=input('enter roll:')
        self.sub1=input('enter marks in sub1:')
        self.sub2=input('enter marks in sub2:')
        self.sub3=input('enter marks in sub3:')
        self.sub4=input('enter marks in sub4:')
    def calc(self):
        total=0
        avg=0
        self.total=self.sub1+self.sub2+self.sub3+self.sub4
        self.avg=self.total/4
    def output(self):
        print 'name',self.name
        print 'roll no.',self.roll
        print 'total',self.total
        print 'average',self.avg
s = stu()
s.input()
s.calc()
s.output()
s1=stu()
s1.input()
s1.calc()
s1.output()
'''
class stu:
    def input(self):
        name=raw_input('enter name:')
        roll=input('enter roll:')
        self.sub1=input('enter marks in sub1:')
        self.sub2=input('enter marks in sub2:')
        self.sub3=input('enter marks in sub3:')
        self.sub4=input('enter marks in sub4:')
        
    def calc(self):
        total=0
        avg=0
        self.total=self.sub1+self.sub2+self.sub3+self.sub4#need to use self becoz in the same class we have define that instance
        self.avg=self.total/4#here it is taking inner total not object's total
    def output(self):
        print 'name',self.name#NameError: global name 'name' is not defined,if  you write without self
        print 'roll no.',self.roll
        print 'total',self.total
        print 'average',self.avg
stuarray=[]
s = stu()
s1=stu()
s2=stu()
stuarray.append(s)
stuarray.append(s1)
stuarray.append(s2)
for i in range(0,3):
    stuarray[i].input()
    stuarray[i].calc()
    stuarray[i].output()
    '''
s1=input('enter ist no:')
print s1/100.0*10-.4# same as s1*10/100.0-.4
'''


