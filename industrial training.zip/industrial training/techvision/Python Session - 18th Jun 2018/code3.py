a =1
b =2

if a>b:
    print a
    print 'a is greater'
else:
    print b
    print 'b is grater'

##
ids = input('enter id : ')
name = raw_input('enter name : ')
hs = input('enter marks in hindi : ')
es = input('enter marks in english : ')
cs = input('enter marks in computer sci. : ')
ms = input('enter marks in maths. : ')


total  =hs+es+cs+ms
avg = total /4
print 'total score is ',total
print 'average score is ',avg

if avg>=80:
    print 'A'
elif avg>=60:
    print 'B'
elif avg>=50:
    print 'C'
else:
    print 'D'
