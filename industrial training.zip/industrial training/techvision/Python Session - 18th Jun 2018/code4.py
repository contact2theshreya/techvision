a =1
b =33
c =44

##show greater no.
if a>b and a>c:
    print 'a is gt'
elif b>a and b>c:
    print 'b is gt'
else:
    print 'c is gt'

## nested if 
if a>b:
    if a>c:
        print 'a is gt'
    else:
        print 'C is gt'
else:
    if b>c:
        print  'b is gt '
    else:
         print  'C is gt '       

