from Tkinter import *
import mysql.connector
win1=Tk()
win1.geometry('500x500')
win1.title('Registration Form')
def page1():
    
    win1=Tk()

    win1.geometry('500x500')
    win1.title('Registration Form')
    Fullname=StringVar()


    l1=Label(win1,text="Full name",width=20,font=("bold",10),state='disabled')
    l1.place(x=80,y=130)
    e1=Entry(win1,state='disabled')
    e1.place(x=240,y=130)
    Button(win1,text='page2',width=20,bg='brown',fg='white',command=nav).place(x=180,y=400)
   
def nav():
    win1=Tk()
    win1.geometry('500x500')
    win1.title('page1')
    Button(win1,text='Go back to page 1',width=20,bg='brown',fg='white',command=page1).place(x=180,y=380)
    
Button(win1,text='press',width=20,bg='brown',fg='white',command=page1).place(x=180,y=380)
    
mainloop()


