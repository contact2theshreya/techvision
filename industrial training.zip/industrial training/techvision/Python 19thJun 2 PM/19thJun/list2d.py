emp = [] # declare empty list 

while True:
    op = input('enter 1. for add 2. for show 3. for exit ')

    if op ==1:
        ids = input('enter id :')
        name = raw_input('enter name :')
        sal = input('enter sal :')
        row= []# 2d array
        row.append(ids)
        row.append(name)
        row.append(sal)

        emp.append(row)        

    elif op  ==2:
        for r in emp:
            print r
    elif op ==3:
        print 'thank you using my CRUD app'
        break
    else:
        print 'invalid choice!!!'    






