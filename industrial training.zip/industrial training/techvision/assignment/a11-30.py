'''
---------------program to print ascii value of character------
c = raw_input("Enter a character: ")

print("The ASCII value of '" + c + "' is",ord(c))
----------ascii to character---------
n=input('enter no:')
print chr(n)
-----WAP to find out the quotient and remainder of two numbers. ( Without using modulus ( % )  operator)----------
a=input('enter dividend:')
b=input('enter divisor:')
r=a-b
q=1
while r>=b:
    r=r-b
    q+=1
print 'quotient',q
print 'remainder',r
---------input two numbers and print the greatest using conditional operator.-------------    
a=input('enter ist no.:')
b=input('enter 2nd no:')
#big = a > b ? (a > c ? a : c) : (b > c ? b : c) 
big=[b,a][a>b]
print 'biggest no is',big 
--------input inches from the user and convert it into yards, feet and inches.-----------
inches = input('enter inche')
yards = 36
feet = 12
totalYards = 0
totalFeet = 0
totalInches = 0
totalYards = inches%36
totalFeet = inches%12
totalInches = inches
print 'feet',totalFeet,'yard'.totalYards
 -----even or odd using conditional operator.--------------
a=input('enter number:')
bool=[0,1][a%2==0]
if bool==0:
    print 'odd'
else:
    print 'even' 
-------biggest among three no. using conditional operator-------
a=input('enter ist no.:')
b=input('enter 2nd no:')   
c=input('enter 3rd no:')
big=[[c,b][b>c],a][a>b and a>c]
print 'biggest among three no. is',big
---------to print current date and time---------
from datetime import date
from datetime import time
from datetime import datetime
today=date.today()
time1=datetime.now()
print 'todays date is ',today
print 'todays time is ',time1
-----------------find the age of a person by the given date of birth---------------------------------
'''

print("please enter your birthday")
bd_y=int(input("Year:"))
bd_m=int(input("Month(1-12):")) 
bd_d=int(input("Date:"))
from datetime import date
now = date.today ()

age = date(int(bd_y),int(bd_m), int(bd_d))
print ("your age is " +str((now-age)/365)+'in years')




