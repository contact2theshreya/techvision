'''
from tkinter import*
win=Tk()
l1=Label(text='First name')
l1.pack()
t1=Entry()
t1.pack()
l2=Label(text='Last name')
l2.pack()
t2=Entry()
t2.pack()
lo =Label()
lo.pack()
def add():
    print('you have clicked on button') 
    fn=t1.get()
    ln=t2.get()
    lo.config(text=fn+' '+ln)
b1=Button(text='submit',command=add)
b1.pack()


win.mainloop()

#tuple
product=("dove","son phone","hp laptop")
while True:
    s=input('enter product')
    if s in product:
        print('product found,you can buy this')
        break
    else:
        print('not avvailable')
        
#dict
prod={"dove":54,"sony laptop":97,"hp phone":88}
p=input("enter product we will show you the price if it is available in the stock")
print (prod[p])
prod['new key']=5543
#prod[11]=544
#prod['11']=544//{'dove': 54, 'sony laptop': 97, 'hp phone': 88, 'new key': 5543, '11': 544}
print(prod)
for item in prod:
    if prod[item]>100:
      print(item,':',prod[item])

sirs method

for k,v in prod:
    if v>100:
      print(k,':',prod[k])
'''
import re
'''
data=input('enter data to match')
o=re.match(r"(.*)are(.*)",data)
if o:
    print('are is exist')
else:
    print('not match')
'''    
###check email id
data=input('enter data email id')
o=re.match(r"(.*)@gmail.com",data)
o1=re.match(r"(.*)@yahoo.com",data)
o2=re.match(r"(.*)@yahoo.co.in",data)
if o or o1 or o2:
    print('email is in correct format')
else:
          print('email is in incorrect format')
o3=re.match(r"([a-zA-Z0-9]+)@yahoo.com",data)
if o3:
    print('true')
else:
    print('false')
