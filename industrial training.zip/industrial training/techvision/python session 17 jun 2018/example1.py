salary = input('enter salary:')
if salary >=5000 and salary <=10000:
    print 'HR ' ,salary*.1 ,'and DA ',salary/20
elif salary >=10001 and salary <=15000:
    print 'HR ' ,salary*.15 ,'and DA ', salary*.08
else:
    print 'default'
                        
