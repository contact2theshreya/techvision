from functionex import welcome,sumNum


'''
import functionex

functionex.welcome()
functionex.sumNum(1111,2)
'''

welcome()
sumNum(1,2)


