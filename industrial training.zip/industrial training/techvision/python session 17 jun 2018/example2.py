ids = input('enter iD :')
name = raw_input('enter name:')
hs = input('enter marks in hindi :')
es = input('enter marks in english :')
cs = input('enter marks in ccomputer :')
ms = input('enter marks in maths :')
sc = input('enter marks in science :')


total =hs+es+cs+ms+sc
per = total / 5
print 'total score is ',total
print 'percentage  is ',per

#print percentage
if per >=60:
    print 'First'
elif per >=50 and per <=59:
    print 'second'
elif per >=40 and per<=49:
    print 'third'
else:
    print 'fail'

