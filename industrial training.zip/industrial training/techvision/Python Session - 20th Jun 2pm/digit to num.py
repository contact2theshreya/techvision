num=raw_input('enter three digit word:')
l=list(num)
t= l[0]
hundred=['','one','two','three','four','five','six','seven','eight','nine']
tens=['','','twenty','thirty','fourty','fifty','sixty','seventy','eighty','ninety']
ones=['','one','two','three','four','five','six','seven','eight','nine']

print hundred[int(t)],
print 'hundred',
if l[1]=='1':
    t2=l[2]
    emp=['ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen']
    print emp[int(l[2])],
else:
    t1=l[1]
    t2=l[2]
    print tens[int(t1)],
if l[1]!='1':
    
    print ones[int(t2)]               
'''
def get():
    t2=l[2]
    emp=['ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen']
    print emp[int(t2)],
'''
