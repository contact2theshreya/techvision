# -*- coding: utf-8 -*-
#from __future__ import unicode_literals

#from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.http import HttpResponse 
from django.shortcuts import render_to_response
# Create your views here.
def index(request):
     return render_to_response("music/index.html")
    # return HttpResponse("<h1>this is the music app</h1>")
def login(request):
    #return HttpResponse ("hi")
    return render_to_response("music/login.html")
def signup(request):
    #return HttpResponse ("hi")
    return render_to_response("music/signup.html")    
def save(request):
    fn=request.GET['fn']
    ln =request.GET['ln']

    f  = open(r'output.txt','a')
    f.write(fn+','+ln)
    f.close()
  
        
    return HttpResponse ("data is saved")
def save1(request):
    email=request.GET['email']
    pswd =request.GET['pswd']

    f  = open(r'output.txt','a')
    f.write(email+','+pswd)
    f.close()
    return HttpResponse ("data is saved")







   
    

