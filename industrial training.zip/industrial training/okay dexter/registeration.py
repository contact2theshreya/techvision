from Tkinter import *
import mysql.connector
root=Tk()
win=Tk()
win.geometry('500x500')
win.title('page1')
root.geometry('500x500')
root.title('Registration Form')
Fullname=StringVar()
Email=StringVar()
var=IntVar()
c=StringVar()
var1=IntVar()

con = mysql.connector.connect(user='root',password='root',host='localhost',database='store')

l1=Label(root,text="Full name",width=20,font=("bold",10))
l1.place(x=80,y=130)
e1=Entry(root)
e1.place(x=240,y=130)
l2=Label(root,text="Email",width=20,font=("bold",10))
l2.place(x=68,y=180)
e2=Entry(root)
e2.place(x=240,y=180)
def database():
    name1=e1.get()
    email=e2.get()
    gender=var.get()
    country=c.get()
    prog=var1.get()
    con = mysql.connector.connect(user='root',password='root',host='localhost',database='store')
    if gender==0:
        ag='male'
    else:
        ag='female'

def nav():
    Button(win,text='Go back to page 1',width=20,bg='brown',fg='white',command=page1).place(x=180,y=380)
    
#create object of cursor : cursor will execute or fire the sql command 
    cr = con.cursor()
    cr.execute("insert into student1(fullname,email,gender,country,programming) values('"+str(name1)+"','"+email+"','"+ag+"','"+country+"','"+str(prog)+"')")
    #cr.execute("select * from student1")
#save data 
    con.commit()
    con.close()


    
l0=Label(root,text="Registration Form",width=20,font=("bold",20))
l0.place(x=90,y=53)
#l1=Label(root,text="Full name",width=20,font=("bold",10))
#l1.place(x=80,y=130)
'''
e1=Entry(root)
e1.place(x=240,y=130)
l2=Label(root,text="Email",width=20,font=("bold",10))
l2.place(x=68,y=180)

e2=Entry(root)
e2.place(x=240,y=180)
'''
l3=Label(root,text="gender",width=20,font=("bold",10))
l3.place(x=70,y=230)

var=IntVar()
Radiobutton(root,text="Male",padx=5,variable="var1",value="male").place(x=235,y=230)
Radiobutton(root,text="Female",padx=20,variable="var2",value="female").place(x=290,y=230)
l4=Label(root,text="country",width=20,font=("bold",10))

l4.place(x=70,y=280)
list1=['canada','india','uk']
#c=StringVar()
droplist=OptionMenu(root,c,*list1)
droplist.config(width=15)
c.set('select your country')
droplist.place(x=240,y=280)
l5=Label(root,text="Proggraming",width=20,font=("bold",10))

l5.place(x=85,y=330)
var1=IntVar()
var2=IntVar()
Checkbutton(root,text="java",variable=var1).place(x=235,y=330)
Checkbutton(root,text="Python",variable=var2).place(x=290,y=330)
Button(root,text='submit',width=20,bg='brown',fg='white',command=database).place(x=180,y=380)
Button(root,text='page1',width=20,bg='brown',fg='white',command=nav).place(x=180,y=400)
mainloop()


