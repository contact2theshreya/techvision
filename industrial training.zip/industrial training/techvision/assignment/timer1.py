import time
import os
import threading
import shutil
src=[]
#src =r"C:\Users\mihir\Desktop\output.txt"
dest =r"C:\Users\mihir\Desktop\nidhi"



def fun2():

     for i in range(0,4):
                  try:
                  
                   shutil.move(src[i],dest)
                   print 'file'+str(i)+'is moved'
                   time.sleep(10)
                  except:
                   print('there is some technical error')


def fun1():

     for i in range(0,4):
          try:
            filename='output'+str(i)+'.txt'
            src.append(r"C:\Users\mihir\Desktop\\"+filename)
            f = open(r'C:\Users\mihir\Desktop\\'+filename,'w')
            print str(i)+' file is created'
            time.sleep(1)
            f.close()
            fun2()
          except:
            print('there is some technical error')
          
          

p1 = threading.Thread(name="process1",target=fun1)
#p2 = threading.Thread(name="process2",target=fun2)

p1.run()
p2.run()





