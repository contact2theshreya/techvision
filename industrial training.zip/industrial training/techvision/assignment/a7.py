a=input('enter the value of a:')
b=input('enter the value of b:')
c=input('enter the value of c:')
d=input('enter the value of d:')
if a**3 + b**3 + c**3==d**3:
    print 'satisfied'
else:
    print 'unsatisfied'
si=a * b * c    
print si / 100.0#note division by 100