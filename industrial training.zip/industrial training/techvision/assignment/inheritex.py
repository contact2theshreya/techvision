class calc: # parent class

    def add(s,a,b):
        c =a+b
        print c


#child class
class dcalc(calc):  # extend class clac to class dcalc 
    def mul(self,a,b):
        c =a*b#error in self.a says tax instance has no attribute a so you will use self,if that class has an instance
        print(c)

#class  tax
class tax(dcalc):
    def computeTax(self,amt):
        if amt<300000:#self means same class attr
            print 'no tax'
        
        else:
            print 'taxable income'



            

##create object
        
t =tax()
t.add(11,2)
#t.mul(11,2)
t.computeTax(1122300)
t.mul(33,44)









