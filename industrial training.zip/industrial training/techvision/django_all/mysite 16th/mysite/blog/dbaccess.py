import mysql.connector


#print(con)
def newUser(name,email):
    con = mysql.connector.connect(user="root",password="root",host="localhost",database="django_app")
    cur = con.cursor()
    cur.execute("insert into user_info(name,email) values('"+name+"','"+email+"')")
    con.commit()
    print('row inserted')
    con.close()

def validateUser(name,email):
    con = mysql.connector.connect(user="root",password="root",host="localhost",database="django_app")
    cur = con.cursor()
    cur.execute("select * from user_info where name='"+name+"' and email='"+email+"'")

    res = cur.fetchall()
    d = []
    for r in res:
        a=[]
        a.append(r[0])
        a.append(r[1])
       # a.append(r[2])

        d.append(a)
        
    return d 




