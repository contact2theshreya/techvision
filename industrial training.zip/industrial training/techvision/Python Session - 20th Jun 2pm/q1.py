f= open(r'C:\Users\mihir\Desktop\test.txt','r')
'''
id,name,gender,country,salary
1,raman,male,india,2233
2,chahat,female,nepal,2345
3,rahul,male,india,2425
4,rubby,female,nepal,4245
'''
rows = f.readlines()
mc=0
fc=0
for r in rows:
    word = r.split(',')
    if word[2]=='male':
         mc=mc+1
    
    elif word[2]=='female':
        fc=fc+1
print 'male is:',mc
print 'female is:',fc
f.close()
