from django.contrib import admin
from.models import album,song,emp
admin.site.register(album)
admin.site.register(song)
admin.site.register(emp)

# Register your models here.
