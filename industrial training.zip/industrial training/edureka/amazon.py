from bs4 import BeautifulSoup as soup 
import requests
from urllib2 import urlopen as ureq
myurl='https://www.amazon.in/s/ref=nb_sb_noss_2?url=search-alias%3Daps&field-keywords=iphones'
uclient=ureq(myurl)
pagehtml=uclient.read()
uclient.close()
pagesoup=soup(pagehtml,"html.parser")
containers=pagesoup.findAll("div",{"class":"s-item-container"})#a-fixed-left-grid
print(len(containers))
container=containers[0]
#print(container)
count=0



for container in containers:
                    count=count+1
                    print(count,"############################################################")
                    print(container.div.img["alt"])
                    price=container.findAll("div",{"class":"a-column a-span7"})#findAll("span",{"class":"a-size-base a-color-price s-price a-text-bold"})
                    #print price
                    arr=[]
                    for string in price[0].stripped_strings:
                        arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                    #print arr
                    p1=list(arr)
                    word=p1[0].split('u\'')
                    print 'Rs'+ word[1].replace('\'',' ')
                    prod_rat=container.findAll("div",{"class":"a-column a-span5 a-span-last"})#findAll("i",{"class":"a-icon a-icon-star a-star-3-5"})
                    rat=[]
                    for string in prod_rat[0].stripped_strings:
                        rat.append(repr(string))
                    r1=list(rat)
                    word1=r1[0].split('u\'')
                    print word1[1].replace('\'',' ')
                    word3=r1[1].split('u\'')
                    print word3[1].replace('\'',' ')
                    
                    rev=container.findAll("a",{"class":"a-size-small a-link-normal a-text-normal"})########******************************************
                    #print rev


                    rat1=[]
                    for string in rev[1].stripped_strings:
                        rat1.append(repr(string))
                    rat2=list(rat1)
                    #print rat2
                    word2=rat2[0].split('u\'')
                    print word2[1].replace('\'',' ')
                                    
