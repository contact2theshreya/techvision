from django.contrib import admin
from django.conf.urls import include, url
from . import views
#contain all functions and html
urlpatterns = [    
    url('home$',views.home,name="home"),
    url('save$',views.save,name="save"),    
    url('yash$',views.yash,name="yash"),
    url('logincheck$',views.logincheck,name='logincheck'),
    url('login$',views.login,name="login"),
    url('',views.index,name="index"), # landing / default page 
    
]
