from Tkinter import*
import mysql.connector
import re
con = mysql.connector.connect(user='root',password='root',host='localhost',database='emp')
cr = con.cursor()

win=Tk()
l1=Label(text='First name')
l1.pack()
t1=Entry()
t1.pack()
l2=Label(text='Last name')

l2.pack()
t2=Entry()
t2.pack()
lo =Label()
lo.pack()
l5=Label()
l5.pack(side=LEFT)
def add():
    print('you have clicked on button') 
    fn=t1.get()
    ln=t2.get()
    pattern = re.compile("\W")#allow only characters

    status = re.search(pattern, fn)
    #o3=re.match(r"([a-zA-Z]+)",fn)
    o3=re.match(r"\W",fn)#running with both status and o3 both two of the method are working
    if o3:
      lo.config(text=fn+' '+ln)
      l5.config(text='saved')
      cr.execute("insert into form(firstname,lastname) values('"+fn+"','"+ln+"')")
      con.commit()
    else:
        print 'sorry,try again'


b1=Button(text='submit', width=25,command=add)
b1.pack()
#con.commit()


win.mainloop()
cr.execute('select * from form')

res = cr.fetchall()
for r in res:
    print r

con.close()


'''
import re

data=input('enter data to match')
o=re.match(r"(.*)are(.*)",data)
if o:
    print('are is exist')
else:
    print('not match')    
###check email id
data=input('enter data email id')
o=re.match(r"(.*)@gmail.com",data)
o1=re.match(r"(.*)@yahoo.com",data)
o2=re.match(r"(.*)@yahoo.co.in",data)
if o or o1 or o2:
    print('email is in correct format')
else:
          print('email is in incorrect format')
o3=re.match(r"([a-zA-Z0-9]+)@yahoo.com",data)
if o3:
    print('true')
else:
    print('false')
'''

