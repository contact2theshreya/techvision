marks = [] # declare empty list 

while True:
    op = input('enter 1. for add 2. for show 3. remove 4. sort 5. for exit ')

    if op ==1:
        m = input('enter marks :')
        marks.append(m)
    elif op  ==2:
        print marks 
    elif op==3:
        m = input('enter marks to remove  :')
        marks.remove(m)
    elif op ==4:
        marks.sort()
    elif op ==5:
        print 'thank you using my CRUD app'
        break
    else:
        print 'invalid choice!!!'    






