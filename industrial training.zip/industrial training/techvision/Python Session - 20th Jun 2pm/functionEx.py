#no argument no return
def wel():

     print ('welcome to function world.')


#no argument with return
def getData():
     i=input('enter id :')
     n=input('enter name :')
     s=input('enter sal :')
     
     return i,n,s

#argument with no return
def addNum(a,b):
     c =a+b
     print(c)

#argument with return
def subNum(a,b):
     c =a-b
     return c

##function with default argument/optional argument
def add(a,b,c=0,d=0,n=0):
     o =a+b+c+n
     print(o)
     


def mul(a,b):

     o = 1
     if type(a) == list:
          for x in a:
               o = o*x
     else:
          o =a


     if type(b) ==list:
          for x in b:
               o =o*x
     else:
          o =o*b

     print(o)

###
def addNumbers(*args):

     print(args)
     
     o = 0
     for x in args:
          o =o+x

     print(o)
     
#call or invoke to function
wel()
wel()
'''
ids,name,sal =getData()
print(ids,name,sal)
ids,name,sal =getData()
print(ids,name,sal)
'''

emp = []
emp.append(getData())
#emp.append(getData())
#emp.append(getData())
#emp.append(getData())

print(emp)

addNum(11,22)

a =subNum(11,2)
print(a)

##call to  function with default/optional argument
add(11,2)
add(11,233,4)
add(11,2,4344,5)
add(11,2,444,5,5)


##
a =1
b =3
mul(a,b)
mul(11,[111,2,3])
mul([11,2,3],[33,44,5])


##
addNumbers(111,222,3,3,4,4,5)
addNumbers(111,222,3,3,4,4,5,4,44,3,3,3,34,4,4,5,5)
