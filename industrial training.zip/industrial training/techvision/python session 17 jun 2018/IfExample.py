ids = input('enter id :')
name = raw_input('enter name:')
hs = input('enter marks in hs :')
es = input('enter marks in es :')
cs = input('enter marks in cs :')
ms = input('enter marks in ms :')

total =hs+es+cs+ms
avg = total / 4

print 'total score is ',total
print 'average score is ',avg

#print grade
if avg >=80:
    print 'Grade A'
elif avg>=60:
    print 'Grade B'
elif avg>=50:
    print 'Grade C'
else:
    print 'Grade D'





    
    

    




