str=raw_input('enter string:')
l=list(str)
print len(l)#equal to length of str
found=False
for i in range(0,len(str)):
     if found==False and l[i]!=' ':
            l[i]=l[i].upper()
            found=True
           
           
     elif l[i]== ' ':
            found=False
         
print
print ' '.join(l)# convert list to string representation
        
        

        




        
        

        
