##list
data = [3333,2,2,2,333]
data[1] = 100

print data[1]

##Dict
words = {'a':'alpha','b':'beta','c':'ceta','t':'tata'}
words['b'] = 'ball'


print words

ch = raw_input('enter char to search ')
print words[ch]

#example
emps = {101:[101,'nitin',23,'male'], 102:[102,'raman',25,'male'],
        103:[103,'monika',26,'female']}

print emps[102]

##Tuple## readonly

wdays = ('mon','tue','wed','thu','fri')
day = raw_input('enter day name  :')
if day in wdays:
    print 'working days'
else:
    print 'weekd end'
    
#@wdays[1] ='sun'   //value cannot be change 


#Set  : contains unique value
products = {'dove','lakme','sony phone','dove'} # 2nd dove will be removed
print products




