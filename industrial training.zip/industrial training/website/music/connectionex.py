import mysql.connector


def saveData(n,e,p):
        
        c = mysql.connector.connect(user="root",password="root",host="localhost",database="test_con")

        cr = c.cursor()
        #cr.execute("insert into emp(name,email,pwd) values('"+n+"','"+e+"','"+p+"')")
        st ="insert into emp(name,email,pwd) values('"+n+"','"+e+"','"+p+"')"
        cr.execute(st)
   
        #cr.execute("select * from emp where name='"+n+"' and email='"+e+"' ")
        c.commit()
        #c.close()
        
        return st

def showTest(n,e,p):
        c = mysql.connector.connect(user="root",password="root",host="localhost",database="test_con")
        cr = c.cursor()
       
        cr.execute("select * from emp where name='"+n+"' and email='"+e+"' ")
        res = cr.fetchall()
        d=[]
        for r in res:
                a=[]
                a.append(r[0])
                a.append(r[1])
                a.append(r[2])
                
        d.append(a)

        return d          

        #c.close()

