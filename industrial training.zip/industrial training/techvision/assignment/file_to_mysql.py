import mysql.connector

con = mysql.connector.connect(user='root',password='root',host='localhost',database='emp') 
cr = con.cursor()
f= open(r'C:\Users\mihir\Desktop\emp_record.txt','r')
#f.readline()

lines=f.readlines()
count=1
for r in lines:
    count=count+1
    w=r.split(',')

    if count == 2:
       continue

    cr.execute("insert into record(id,name,gender) values("+w[0]+",'"+w[1]+"','"+w[2].replace('\n','')+"')")#'"+(w[0])+"' or always have single quotes in string
                                                                                                                 #'"+w[0]+"' or "+w[0]+"(becoz w by default  contain string)
#cr.execute("delete from record")
#save data 
con.commit()
print count

#print '1 row inserted'

f.close();

## read data
cr.execute('select * from record')

res = cr.fetchall()
for r in res:
    print r

con.close()





