roll=input('enter roll no:')
name=raw_input('enter name:')
marks=input('enter marks')
phone_no=input('enter phone no:')
print 'name is:',name,'roll no',roll,'marks',marks,'phone',phone_no