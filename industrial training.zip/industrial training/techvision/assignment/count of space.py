f = open(r'C:\Users\mihir\Desktop\nidhi\industrial training\output.txt','r')

nos=0
not1=0
newline=0
wc=0
list = f.readlines()

for r in list:
    word = r.split(' ')# word for alll iteration=['shreya', 'is', 'a', 'good', 'girl\n']

    wc = wc+ len(word)
    if '\t' in r:
        not1+=1
    if '\n' in r:
        newline+=1
    if ' ' in r:
        nos+=1
nos=wc-2
print 'no. of space',nos,'no. of tabs',not1,'new line',newline        
print 'the count of'+' space '+' is ',nos
f.close()
               


