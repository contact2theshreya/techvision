from django.contrib import admin
from django.conf.urls import include, url
from . import views

urlpatterns = [  
    url('login$',views.login,name="login"), 
    url('save$',views.save,name="save"),
    url('save1$',views.save1,name="save1"),#save1 for registration
    url('signup$',views.signup,name="signup"),
    url('',views.index,name="index") # landing / default page 
    
]
