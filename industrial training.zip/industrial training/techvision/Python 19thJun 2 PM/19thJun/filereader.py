f = open('C:\Users\Tech Vision\Desktop\data.txt','r')

#print f.read()
#print f.readline()  
#print f.readline() 

rows = f.readlines()
l = len(rows)

#print rows 

for r in rows:
    #col = r.split(',')
    #print col[1],col[3].replace('\n','')
    print r 

print  'no of rows = ',l

f.close()




