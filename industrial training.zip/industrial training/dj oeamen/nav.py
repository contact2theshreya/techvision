from Tkinter import*


def add():
    root=Tk()
    root.geometry("1600x800+0+0")
    root.title("Restaurant management system")
    l1=Label(root,text="Full name",width=20,font=("bold",10))
    l1.place(x=80,y=130)
    drinks=StringVar()
    textdrinks=Entry(root,font=('arial',16,'bold'),textvariable=drinks,bd=10,insertwidth=4,bg="#ffffff",justify='right')
    textdrinks.grid(row=0,column=3)
    a=5+2
    drinks.set(str(a))
    mainloop()    
