#declaration of variable
'''
there are two variables in this programa
-sum of two numbers
-developed by:
-developed datae:

'''

a =1
b =2


c=          a     +b

print c

