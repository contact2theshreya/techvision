from Tkinter import*
import sys
import os
import time;
import nav
import random
root=Tk()
root.geometry("1600x800+0+0")
root.title("Restaurant management system")
text_Input=StringVar()
operator=""
tops=Frame(root,width=1600,height=50,bg="powder blue",relief=SUNKEN)
tops.pack(side=TOP)
f1=Frame(root,width=800,height=700,relief=SUNKEN)
f1.pack(side=LEFT)
f2=Frame(root,width=300,height=700,relief=SUNKEN)
f2.pack(side=RIGHT)
localtime=time.asctime(time.localtime(time.time()))
lblinfo=Label(tops,font=('arial',50,'bold'),text="Restaurant management system",fg="steel blue",bd=10,anchor='w')
lblinfo.grid(row=0,column=0)
lblinfo=Label(tops,font=('arial',20,'bold'),text=localtime,fg="steel blue",bd=10,anchor='w')
lblinfo.grid(row=1,column=0)
def btnclick(numbers):
    global operator
    operator=operator+str(numbers)
    text_Input.set(operator)
def buttoncleardisplay():
    global operator
    operator=""
    text_Input.set("")
def buttonequalsinput():
    global operator#in the absence of global it doesnot display the value
    sumup=str(eval(operator))
    
    text_Input.set(sumup)
    operator=""
def ref():
    x=random.randint(10908,50876)
    randomref=str(x)
    rand.set(randomref)
    cof=float(fries.get())
    cod=float(drinks.get())
    cofillet=float(filet.get())
    coburger=float( burger.get())
    cochickenburger=float(chicken_burger.get())
    cocheeseburger=float(cheese_burger.get())

    costoffries=cof*0.99
    costofdrinks=cod*1.00
    costoffillet=cofillet*2.99
    costofburger=coburger*2.87
    costofchickenburger=cochickenburger*2.89
    costofcheeseburger=cocheeseburger*2.69
    costofmeal="$",str('%.2f' % (costoffries + costofdrinks+  costoffillet+costofburger+ costofchickenburger+ costofcheeseburger))
    paytax= ((costoffries + costofdrinks+  costoffillet+costofburger+ costofchickenburger+ costofcheeseburger)*0.2)
    totalcost=(costoffries + costofdrinks+  costoffillet+costofburger+ costofchickenburger+ costofcheeseburger)
    ser_charge=((costoffries + costofdrinks+  costoffillet+costofburger+ costofchickenburger+ costofcheeseburger)/99)
    service="$",str('%.2f' % ser_charge)
    overallcost="$",str('%.2f' % (ser_charge+paytax+totalcost))#2 decimal place after floating point
    paidtax=str('%.2f' % paytax)
    service_charge.set(service)
    cost.set(costofmeal)
    tax.set(paidtax)
    subtotal.set(costofmeal)
    total.set(overallcost)
    
    
    
def qexit():
    root.destroy
def reset():
    rand.set("")
    fries.set("")
    burger.set("")
    filet.set("")
    subtotal.set("")
    total.set("")
    service_charge.set("")
    drinks.set("")
    tax.set("")
    cost.set("")
    chicken_burger.set("")
    cheese_burger.set("")
    
txtdisplay=Entry(f2,font=('arial',20,'bold'),bd=30,textvariable=text_Input,insertwidth=4,bg="powder blue",justify='right')
txtdisplay.grid(columnspan=4)
btn7=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="7",bg="powder blue",command=lambda:btnclick(7)).grid(row=2,column=0)#in absence of lambda 7 is bydefault in texbox
btn8=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="8",bg="powder blue",command=lambda:btnclick(8)).grid(row=2,column=1)
btn9=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="9",bg="powder blue",command=lambda:btnclick(9)).grid(row=2,column=2)
Addition=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="+",bg="powder blue",command=lambda:btnclick("+")).grid(row=2,column=3)
btn4=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="4",bg="powder blue",command=lambda:btnclick(4)).grid(row=3,column=0)#in absence of lambda 7 is bydefault in texbox
btn5=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="5",bg="powder blue",command=lambda:btnclick(5)).grid(row=3,column=1)
btn6=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="6",bg="powder blue",command=lambda:btnclick(6)).grid(row=3,column=2)
subtraction=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="-",bg="powder blue",command=lambda:btnclick("-")).grid(row=3,column=3)
btn1=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="1",bg="powder blue",command=lambda:btnclick(1)).grid(row=4,column=0)#in absence of lambda 7 is bydefault in texbox
btn2=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="2",bg="powder blue",command=lambda:btnclick(2)).grid(row=4,column=1)
btn3=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="3",bg="powder blue",command=lambda:btnclick(3)).grid(row=4,column=2)
multiply=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="*",bg="powder blue",command=lambda:btnclick("*")).grid(row=4,column=3)
btn0=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="0",bg="powder blue",command=lambda:btnclick(0)).grid(row=5,column=0)#in absence of lambda 7 is bydefault in texbox
btnequal=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="=",bg="powder blue",command=buttonequalsinput).grid(row=5,column=1)
btnclear=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="c",bg="powder blue",command=buttoncleardisplay).grid(row=5,column=2)
Division=Button(f2,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="/",bg="powder blue",command=lambda:btnclick("/")).grid(row=5,column=3)

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
rand=StringVar()
fries=StringVar()
burger=StringVar()
filet=StringVar()
subtotal=StringVar()
total=StringVar()
service_charge=StringVar()
drinks=StringVar()
tax=StringVar()
cost=StringVar()
chicken_burger=StringVar()
cheese_burger=StringVar()
lblreference=Label(f1,font=('arial',16,'bold'),text="Reference",bd=16,anchor='w')
lblreference.grid(row=0,column=0)
textreference=Entry(f1,font=('arial',16,'bold'),textvariable=rand,bd=10,insertwidth=4,bg="powder blue",justify='right')
textreference.grid(row=0,column=1)
lblfries=Label(f1,font=('arial',16,'bold'),text="Large Fries",bd=16,anchor='w')
lblfries.grid(row=1,column=0)
textfries=Entry(f1,font=('arial',16,'bold'),textvariable=fries,bd=10,insertwidth=4,bg="powder blue",justify='right')
textfries.grid(row=1,column=1)
lblburger=Label(f1,font=('arial',16,'bold'),text="burger meal",bd=16,anchor='w')
lblburger.grid(row=2,column=0)
textburger=Entry(f1,font=('arial',16,'bold'),textvariable=burger,bd=10,insertwidth=4,bg="powder blue",justify='right')
textburger.grid(row=2,column=1)
lblfilet=Label(f1,font=('arial',16,'bold'),text="Filet_o_meal",bd=16,anchor='w')
lblfilet.grid(row=3,column=0)
textfilet=Entry(f1,font=('arial',16,'bold'),textvariable=filet,bd=10,insertwidth=4,bg="powder blue",justify='right')
textfilet.grid(row=3,column=1)
lblchicken=Label(f1,font=('arial',16,'bold'),text="chicken meal",bd=16,anchor='w')
lblchicken.grid(row=4,column=0)
textchicken=Entry(f1,font=('arial',16,'bold'),textvariable=chicken_burger,bd=10,insertwidth=4,bg="powder blue",justify='right')
textchicken.grid(row=4,column=1)

lblcheese=Label(f1,font=('arial',16,'bold'),text="cheese meal",bd=16,anchor='w')
lblcheese.grid(row=5,column=0)
textcheese=Entry(f1,font=('arial',16,'bold'),textvariable=cheese_burger,bd=10,insertwidth=4,bg="powder blue",justify='right')
textcheese.grid(row=5,column=1)
#-----------------------------------------------------------------------Restaurant info2----------------------------------------------------------------------------------------------------
lbldrinks=Label(f1,font=('arial',16,'bold'),text="Drinks",bd=16,anchor='w')
lbldrinks.grid(row=0,column=2)
textdrinks=Entry(f1,font=('arial',16,'bold'),textvariable=drinks,bd=10,insertwidth=4,bg="#ffffff",justify='right')
textdrinks.grid(row=0,column=3)

lblcost=Label(f1,font=('arial',16,'bold'),text="cost of meal",bd=16,anchor='w')
lblcost.grid(row=1,column=2)
textcost=Entry(f1,font=('arial',16,'bold'),textvariable=cost,bd=10,insertwidth=4,bg="#ffffff",justify='right')
textcost.grid(row=1,column=3)

lblservice=Label(f1,font=('arial',16,'bold'),text="service charge",bd=16,anchor='w')
lblservice.grid(row=2,column=2)
textservice=Entry(f1,font=('arial',16,'bold'),textvariable=service_charge,bd=10,insertwidth=4,bg="#ffffff",justify='right')
textservice.grid(row=2,column=3)

lblstatetax=Label(f1,font=('arial',16,'bold'),text="state tax",bd=16,anchor='w')
lblstatetax.grid(row=3,column=2)
textstatetax=Entry(f1,font=('arial',16,'bold'),textvariable=tax,bd=10,insertwidth=4,bg="#ffffff",justify='right')
textstatetax.grid(row=3,column=3)

lblsubtotal=Label(f1,font=('arial',16,'bold'),text="sub total",bd=16,anchor='w')
lblsubtotal.grid(row=4,column=2)
textsubtotal=Entry(f1,font=('arial',16,'bold'),textvariable=subtotal,bd=10,insertwidth=4,bg="#ffffff",justify='right')
textsubtotal.grid(row=4,column=3)

lbltotalcost=Label(f1,font=('arial',16,'bold'),text="total cost",bd=16,anchor='w')
lbltotalcost.grid(row=5,column=2)
texttotalcost=Entry(f1,font=('arial',16,'bold'),textvariable=total,bd=10,insertwidth=4,bg="#ffffff",justify='right')
texttotalcost.grid(row=5,column=3)


#--------------------------------------------------------------Buttons----------------------------------------------------------------------------------------------------------
btntotal=Button(f1,padx=16,pady=8,bd=16,fg="black",font=('arial',16,'bold'),width=10,text="total",bg="powder blue",command=ref).grid(row=7,column=1)

btnreset=Button(f1,padx=16,pady=8,bd=16,fg="black",font=('arial',16,'bold'),width=10,text="reset",bg="powder blue",command=reset).grid(row=7,column=2)

btnexit=Button(f1,padx=16,pady=8,bd=16,fg="black",font=('arial',16,'bold'),width=10,text="exit",bg="powder blue",command=qexit).grid(row=7,column=3)
'''
def helloCallBack():
    os.system('nav.py')

'''
btnav=Button(f1,padx=16,pady=8,bd=16,fg="black",font=('arial',16,'bold'),width=10,text="nav",bg="powder blue",command=nav.add).grid(row=7,column=4)








root.mainloop()
