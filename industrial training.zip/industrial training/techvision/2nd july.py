from tkinter import*
win=Tk()
win.mainloop()
