from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener



ckey = 'XHsU2QseSnTBPpw6bm9qU7jFB'
csecret = 'wifB5b0iVlew2jjuKfVjHyGAkSQUSbk6Ld7Dh1sIubnCVpxaFq'

atoken = '1015937201077551104-SJIeEExKgHIcPnZbozCLtggq2BUlL0'
asecret = 'eoaJq1Q30lMeKBMKotxrbcwiZkzNALh3JAFCEdE5XV3bX'
class listener(StreamListener):
    def on_data(self,data):
        print data
        return true
    def on_error(self,status):
        print status
auth=OAuthHandler(ckey,csecret)
auth.set_access_token(atoken,asecret)
twitterstream=Stream(auth,listener())
twitterstream.filter(track=["car"])

 
